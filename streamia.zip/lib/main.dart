import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const StreamiaApp());
}

class StreamiaApp extends StatelessWidget {
  const StreamiaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Streamia Player',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
      ),
      // Startet beim Öffnen der App direkt mit dem SplashScreen (inkl. Logo & Playlist-Prüfung)
      home: const SplashScreen(),
    );
  }
}
