import 'package:flutter/material.dart';
import '../services/playlist_service.dart';

class PlaylistInputScreen extends StatefulWidget {
  const PlaylistInputScreen({Key? key}) : super(key: key);

  @override
  State<PlaylistInputScreen> createState() => _PlaylistInputScreenState();
}

class _PlaylistInputScreenState extends State<PlaylistInputScreen> {
  final _nameController = TextEditingController();
  final _urlController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  
  bool _hasExistingPlaylist = false;
  String _selectedType = 'xtream'; // 'xtream' oder 'm3u'

  @override
  void initState() {
    super.initState();
    _checkExistingPlaylist();
  }

  Future<void> _checkExistingPlaylist() async {
    final exists = await PlaylistService.hasPlaylist();
    setState(() {
      _hasExistingPlaylist = exists;
    });
  }

  Future<void> _savePlaylist() async {
    if (_hasExistingPlaylist) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Freemium-Limit: Es ist bereits 1 Playlist aktiv. Bitte in den Einstellungen löschen!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte einen Namen für die Playlist eingeben')),
      );
      return;
    }

    String data = '';
    if (_selectedType == 'xtream') {
      // Speichere Xtream Daten getrennt durch Trennzeichen oder als String
      data = '${_urlController.text.trim()}|${_userController.text.trim()}|${_passController.text.trim()}';
    } else {
      data = _urlController.text.trim(); // M3U URL
    }

    if (data.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte fülle die erforderlichen Felder aus')),
      );
      return;
    }

    await PlaylistService.savePlaylist(
      type: _selectedType,
      data: data,
      name: name,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Playlist erfolgreich gespeichert!')),
    );

    Navigator.pop(context); // Zurück zum Dashboard
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Playlist hinzufügen (Freemium)'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: _hasExistingPlaylist
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.lock, size: 64, color: Colors.amber),
                    const SizedBox(height: 20),
                    const Text(
                      'Freemium-Beschränkung aktiv',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Du hast bereits eine Playlist gespeichert. In der Freemium-Version ist maximal 1 Playlist erlaubt.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      onPressed: () async {
                        await PlaylistService.clearPlaylist();
                        await _checkExistingPlaylist();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Playlist gelöscht. Du kannst eine neue hinzufügen.')),
                        );
                      },
                      icon: const Icon(Icons.delete),
                      label: const Text('Bestehende Playlist löschen'),
                    ),
                  ],
                ),
              )
            : ListView(
                children: [
                  const Text(
                    'Wähle deinen Playlist-Typ:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('Xtream Codes'),
                          value: 'xtream',
                          groupValue: _selectedType,
                          onChanged: (val) => setState(() => _selectedType = val!),
                        ),
                      ),
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('M3U Link'),
                          value: 'm3u',
                          groupValue: _selectedType,
                          onChanged: (val) => setState(() => _selectedType = val!),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Playlist Name (z.B. Mein Anbieter)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 15),
                  TextField(
                    controller: _urlController,
                    decoration: InputDecoration(
                      labelText: _selectedType == 'xtream' ? 'Server URL (z.B. http://line.tv:8080)' : 'M3U Playlist URL',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  if (_selectedType == 'xtream') ...[
                    const SizedBox(height: 15),
                    TextField(
                      controller: _userController,
                      decoration: const InputDecoration(
                        labelText: 'Benutzername',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      controller: _passController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Passwort',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                  const SizedBox(height: 30),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      backgroundColor: Colors.blueAccent,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: _savePlaylist,
                    child: const Text('Playlist dauerhaft speichern', style: TextStyle(fontSize: 16)),
                  ),
                ],
              ),
      ),
    );
  }
}

